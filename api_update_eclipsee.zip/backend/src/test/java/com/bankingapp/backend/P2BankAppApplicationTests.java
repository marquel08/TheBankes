package com.bankingapp.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P2BankAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
