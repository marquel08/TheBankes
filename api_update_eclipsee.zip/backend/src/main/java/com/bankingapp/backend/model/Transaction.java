package com.bankingapp.backend.model;

public class Transaction {

}
